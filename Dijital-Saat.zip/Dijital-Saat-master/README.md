font için link --> https://fonts.google.com/?query=orbitron&selection.family=Orbitron
kendi arkaplanınızı oluşturmak için link --> https://pattern.flaticon.com/
renk seçimi için link --> http://colorsafe.co/
